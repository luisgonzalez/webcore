This sample application is provided as-is.

Getting Started
-----------------
1. Go to the data directory and executute the sql file on your MySql server
2. Open the config/app.settings. file and modify the "data" section accordingly
3. Verify the following lines in the includes/initialize.inc file
	a. Line 73: Point to a file or folder that exists in your local development environment
	b. Line 44: The virtual path is valid in your local development environment
4. Use junction (or create a symlink in linux) to the webcore library within your application path.
	Example: if your sample application is in: c:/projects/samples/, and the webcore library is in c:/projects/webcore,
	the junction command(s) would be:
	cd c:/projects/sample/
	juntion -s webcore c:/projects/webcore
	
Notes:
* All paths must end with the '/' character
* PHP must have write access to your application directory
* If a widget seems to not behave appropriately, ensure you are using its handleRequest method!
* Use a decent PHP editor such as Komodo IDE, Komodo Edit, or Netbeans for PHP. WebCore's class library is too large to be productive without code completion-enabled editors
* Always render widgets within non-body tags (i.e. div tags)
