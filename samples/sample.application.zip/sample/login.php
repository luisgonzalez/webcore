<?php
// Requires
require_once 'includes/initialize.inc.php';
require_once 'widgets/webcore.widgets.login.php';

if (HttpContext::getRequest()->getRequestVars()->keyExists('logout'))
{
    HttpContext::getSession()->destroy();
    $uri = new UniformResourceIdentifier();
    $uri->removeQueryVariable('logout');
    Controller::transfer($uri->toString());
    HttpResponse::end();
}

/*
if (HttpContext::getUser() !== null)
    Controller::transfer(APPLICATION_ROOT . 'index.php');
*/

// Security
HttpContext::getPermissionSet()->setDefaultResolve(Permission::PERMISSION_ALLOW);
HttpContext::applySecurity();

// Content
$mainView = new LoginWidget();
$mainView->handleRequest();

// Page Setup
$appName = Settings::getSectionValue(Settings::SKEY_APPLICATION, Settings::KEY_APPLICATION_NAME);
$page = new WebPage(
    TEMPLATES_PATH . 'templates.main.php',
    'Logon - ' . $appName);
$page->setUseOutputBuffering(true);
$page->addContent('main', $mainView);

$page->render();
?>