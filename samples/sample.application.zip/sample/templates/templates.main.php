<?php
/**
 * Samples Page template example.
 * Use the WebPage->getCurrent() to get the currently active instance of the WebPage
 * usually, you want to extend the WebPage class for more complex scnarios.
 * @version 1.0.0
 * @author Mario Di Vece <mario@unosquare.com>
 */

class PageHelper
{
    static private $menuView;
    
    static public function preRender()
    {
        $menu = new SiteMenu('siteMenu');
        $indexMenu = new SiteMenuItem('indexMenu', 'Welcome', APPLICATION_ROOT . 'index.php');
        $scaffoldMenu = new SiteMenuItem('scaffoldMenu', 'Scaffold', '');
        $scaffoldMenu->addMenuItem('Grids Designer', APPLICATION_ROOT . 'scaffold.grids.php');
        $scaffoldMenu->addMenuItem('Forms Designer', APPLICATION_ROOT . 'scaffold.forms.php');
        $menu->getMenuItems()->addItem($indexMenu);
        $menu->getMenuItems()->addItem($scaffoldMenu);
        
        self::$menuView = new HtmlSiteMenuView($menu); 
    }
    
    static public function renderMenu()
    {
        if (is_null(HttpContext::getUser()) == true)
            return;
        
        self::$menuView->render();
    }
}

PageHelper::preRender();
HtmlViewManager::registerCssFile('resources/theme.css');
header('Content-Encoding: UTF-8');
HttpResponse::write(MarkupWriter::DTD_XHTML_STRICT . "\r\n");
?>
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
<?php
    HtmlViewManager::render();
?>
        <title><?php echo WebPage::getCurrent()->getTitle(); ?></title>
    </head>
    <body>
        <div id="mainContainer">
            <div id="headerContainer">
                <table>
                    <tr>
                        <td rowspan="2" class="logospan">
                            &nbsp;
                        </td>
                        <td>
                            <h3><?php HttpResponse::getInstance()->write(MarkupWriter::htmlEncode(Settings::getSectionValue(Settings::SKEY_APPLICATION, Settings::KEY_APPLICATION_NAME))); ?></h3>
                        </td>
                    </tr>
                    <tr>
                        <td>
                        <?php
                        if (is_null(HttpContext::getUser()) == false)
                        {
                            $roles = HttpContext::getUser()->getRoles()->implode();
                            echo '<span class="headernav">' . HttpContext::getUser()->getUserName() . " (" . HttpContext::getUser()->getRoles()->implode() . ")";
                            echo ' | <a href="' . APPLICATION_ROOT . 'password.index.php">Change Password</a>';
                            echo ' | <a href="' . FormsAuthentication::getLoginUrl() . '?logout">Log Off</a></span>';
                        }
                        else
                        {
                            //echo '<span class="headernav"><a href="' . FormsAuthentication::getLoginUrl() . '">Sign In</a></span>';
                        }
                        ?>
                        <span class="headernav">
                        <?php
                        // culture link
                        $uri = new UniformResourceIdentifier();
                        if (Resources::getCulture() == CultureInfo::CULTURE_ENUS)
                        {
                            $uri->addQueryVariable('setLang', CultureInfo::CULTURE_ESMX);
                            echo '<a class="culture-esmx" href="' . $uri . '">Este sitio en Espa&ntilde;ol</a>';
                        }
                        else
                        {
                            $uri->addQueryVariable('setLang', CultureInfo::CULTURE_ENUS);
                            echo '<a class="culture-enus" href="' . $uri . '">This site in English</a>';
                        }
                        ?>
                        </span>
                        </td>
                    </tr>
                </table>
                <div id="menuContainer">
                <?php PageHelper::renderMenu(); ?>
                </div>
                <div id="breadcumbContainer">
                <?php WebPage::getCurrent()->renderContent('breadcrumb'); ?>
                </div>
            </div>
            <div id="bodyContainer">
            <?php
            WebPage::getCurrent()->renderContent('main');
            ?>
            </div>
            <div id="footerContainer">
                <?php HttpResponse::getInstance()->write(MarkupWriter::htmlEncode(Settings::getSectionValue(Settings::SKEY_APPLICATION, Settings::KEY_APPLICATION_NAME))); ?>
                 v.<?php echo htmlentities(Settings::getSectionValue(Settings::SKEY_APPLICATION, Settings::KEY_APPLICATION_VERSION)); ?> Unosquare &copy; <?php echo date('Y'); ?><br />
                Powered by <a target="_blank" href="http://www.unosquare.com/">WebCore Framework <?php echo WEBCORE_VERSION_MAJOR . "." . WEBCORE_VERSION_MINOR . "." . WEBCORE_VERSION_REVISION ?></a>
            </div>
        </div>
    </body>
</html>
