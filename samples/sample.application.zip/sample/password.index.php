<?php
// Requires
require_once 'includes/initialize.inc.php';
require_once 'forms.changepassword.php';

if (HttpContext::getUser() == null)
    Controller::transfer(APPLICATION_ROOT . 'index.php');

// Security
HttpContext::getPermissionSet()->setDefaultResolve(Permission::PERMISSION_ALLOW);
HttpContext::applySecurity();

// Content
$mainView = new ChangePasswordForm();
$mainView->handleRequest();

// Page Setup
$appName = Settings::getSectionValue(Settings::SKEY_APPLICATION, Settings::KEY_APPLICATION_NAME);
$page = new WebPage(
    TEMPLATES_PATH . 'templates.main.php',
    'Change Password - ' . $appName);
$page->setUseOutputBuffering(true);
$page->addContent('main', $mainView);

$page->render();
?>