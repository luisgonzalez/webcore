<?php
require_once 'includes/initialize.inc.php';
require_once 'widgets/webcore.widgets.griddesigner.php';

// Security
HttpContext::getPermissionSet()->setDefaultResolve(Permission::PERMISSION_DENY);
HttpContext::getPermissionSet()->addAllowedRole(ROLE_ADMINISTRATOR);
HttpContext::applySecurity();

// Content Setup
$widget = new GridDesignerWidget();
$widget->handleRequest();

$breadCrumb = new Breadcrumb('breadcrumb', 'Grids Designer');
$breadCrumb->addLink('Welcome', APPLICATION_ROOT . 'index.php');
$breadView = new HtmlBreadcrumbView($breadCrumb);

// Page Setup
$page = new WebPage(TEMPLATES_PATH . 'templates.main.php', 'Welcome - ' . Settings::getSectionValue(Settings::SKEY_APPLICATION, Settings::KEY_APPLICATION_NAME));
$page->setUseOutputBuffering(true);
$page->addContent('main', $widget);
$page->addContent('breadcrumb', $breadView);

$page->render();
?>