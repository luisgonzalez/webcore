<?php
/**
 * WebCore 3.0 Application Initialization script
 * This is an example of an typical initialization script that is used in most WebCore applications.
 * @version 1.0.0
 * @author Mario Di Vece <mario@unosquare.com>
 */

 // Role definitions go here
define('ROLE_ADMINISTRATOR', 'Administrator');

/**
 * Defines the current application environment and paths
 * @author Mario Di Vece <mario@unosquare.com>
 */
class EnvironmentDefinition
{
    const ENV_DEV_01 = 0;
    const ENV_PROD = 256;
    const COOKIE_CULTURE = 'application_culture';
    
    static private $environment;
    
    /**
     * Gets the int constant of the current environment
     * @return int
     */
    static public function getEnvironment()
    {
        return self::$environment;
    }
    
    /**
     * Defines the current application environment
     * @param int $environmentName One of the ENV prefixed constants defined in this class
     */
    static public function defineEnvironment($environmentName)
    {
        $fileLocation = str_replace('//', '/', str_replace('\\', '/', realpath(dirname(__FILE__) . '/../') . '/'));
        switch ($environmentName)
        {
            case self::ENV_DEV_01 :
                error_reporting(E_ALL | E_STRICT);
                define("APPLICATION_ROOT", "/sample/");
                define("DOCUMENT_ROOT", $fileLocation);
                break;
            case self::ENV_PROD :
                error_reporting(E_ALL | E_STRICT);
                define("APPLICATION_ROOT", "http://www.sample-app.com/");
                define("DOCUMENT_ROOT", $fileLocation);
                break;
            default :
                $exString = "<pre>No environment defined\nYou need set the environment by using EnvironmentDefinition::defineEnvironment method\n"
                    . "Line " . $ex->getLine() . " on file '" . $ex->getFile() . "'\n"
                    . "Error " . $ex->getCode() . ": " . $ex->getMessage() . "\nStack Trace:\n"
                    . $ex->getTraceAsString() . "</pre>";
                HttpResponse::write($exString);
                HttpResponse::end();
        }
        
        self::$environment = $environmentName;
        
        return;
    }
    
    /**
     * Autodetects the current application environment
     */
    static public function autodetect()
    {
        if (file_exists('C:/projects'))
        {
            self::defineEnvironment(self::ENV_DEV_01);
        }
        else
        {
            self::defineEnvironment(self::ENV_PROD);
        }
        
    }
    
    static public function checkDatabase()
    {
        try
        {
            DataContext::getInstance(); // just to check if the db exists
        }
        catch (Exception $ex)
        {
            $exString = "<pre>No Database Connection!\nYou need to configure a default database in the app.settings file.\n"
                . "Line " . $ex->getLine() . " on file '" . $ex->getFile() . "'\n"
                . "Error " . $ex->getCode() . ": " . $ex->getMessage() . "\nStack Trace:\n"
                . $ex->getTraceAsString() . "</pre>";
            HttpResponse::write($exString);
            HttpResponse::end();
        }
    }
    
    static public function setLanguage()
    {
        $request = HttpRequest::getInstance();
        $queryStringVars = $request->getQueryStringVars();
        if ($queryStringVars->keyExists('setLang'))
        {
            $uri = new UniformResourceIdentifier();
            $uri->removeQueryVariable('setLang');
            $redirectUrl = $uri->toString();
            CookieManager::getInstance()->setCookie(self::COOKIE_CULTURE, $queryStringVars->getItem('setLang'));
            HttpResponse::redirect($redirectUrl);
            return;
        }
        
        $isLangSet = CookieManager::getInstance()->isCookieSet(self::COOKIE_CULTURE);
        if ($isLangSet != true)
        {
            // Set the default culture
            CookieManager::getInstance()->setCookie(self::COOKIE_CULTURE, CultureInfo::CULTURE_ENUS);
            Resources::setUserCulture(CultureInfo::CULTURE_ENUS);
        }
        else
        {
            Resources::setUserCulture(CookieManager::getInstance()->getCookieValue(self::COOKIE_CULTURE));
        }
    }
    
}

EnvironmentDefinition::autodetect();
require_once DOCUMENT_ROOT . "webcore/webcore.php";
Resources::load(DOCUMENT_ROOT . 'config/app.resources');
Settings::load(DOCUMENT_ROOT . 'config/app.settings');
HttpContext::initialize();
ClassLoader::addIncludePath(HttpContext::getDocumentRoot() . 'includes/');
define('TEMPLATES_PATH', HttpContext::getDocumentRoot() . 'templates/');
EnvironmentDefinition::checkDatabase();
EnvironmentDefinition::setLanguage();

?>