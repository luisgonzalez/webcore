<?php
class IndexWidget extends ObjectBase implements IRenderable
{
    protected $textContext = "Widgets: Widgets are controls that get rendered using the HtmlTagWriter object.";
    
    public function &getModel()
    {
        return $this->textContext;
    }
    
    public function render()
    {
        $w = HttpContext::getResponse()->getMarkupWriter();
        $w->openDiv();
        $w->addAttribute('style', 'padding: 6px; margin-top: 6px; margin-bottom:6px; border: 1px solid #ccc;');
        $w->writeContent($this->textContext);
        $w->closeDiv();
    }
}
?>