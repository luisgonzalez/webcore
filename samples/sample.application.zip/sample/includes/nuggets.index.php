<div style="padding: 6px; margin-top: 6px; margin-bottom:6px; border: 1px solid #ccc;">
    Nuggets: Nuggets are plain HTML files that can be wrapped inside HtmlViewCollection objects.
</div>