<?php
class ChangePasswordForm extends WidgetBase
{
    /**
     * Creates a new instance of this class.
     */
    public function __construct()
    {
        $request = HttpRequest::getInstance()->getRequestVars();
        
        $this->model = new Form("formChangePassword", "");
        
        if ($request->keyExists('expired'))
            $this->model->getChildren()->addControl(new TextBlock('info', 'Your password has expired. Please create a new one.'));
            
        $this->model->addField(new PasswordField("password_old", "Current Password"));
        $this->model->addField(new PasswordField('password', 'New Password'));
        $this->model->addField(new PasswordField('password_retry', 'Confirm New Password'));
        
        $this->model->addButton(new Button('save', 'Save', 'buttonSave_Clicked'));
        
        Controller::registerEventHandler("buttonSave_Clicked", array(__CLASS__, "buttonSave_Clicked"));
        
        $this->view = new HtmlFormView($this->model);
        $this->view->setFrameWidth('auto');
        $this->view->setIsAsynchronous(true);
    }
    
    public static function buttonSave_Clicked(&$model, &$event)
    {
        $request = HttpRequest::getInstance()->getRequestVars();
        $model->dataBind($request);
        
        if ($model->validate())
        {
            if (FormsAuthentication::getUser()->password != $request->getValue('password_old'))
            {
                $model->setErrorMessage('The current password is incorrect.');
                return;
            }
            
            if ($request->getValue('password_retry') != $request->getValue('password'))
            {
                $model->setErrorMessage('The new password fields do not match.');;
                return;
            }
            
            $id = FormsAuthentication::getUser()->getUserId();
            $user = DataContext::getInstance()->getAdapter('users')->single($id);
            $user->password = $request->getValue('password');
            //$user->password_expires = date('Y-m-d', strtotime("+60 days"));
            
            try
            {
                DataContext::getInstance()->getAdapter('users')->update($user);
            } catch (Exception $ex) {
                $model->setErrorMessage('Error updating.');
                return;
            }
            
            Controller::transfer(APPLICATION_ROOT . 'login.php?logout');
        }
    }
    
    /**
     * Creates a default instance of this class.
     * @return ChangePasswordForm
     */
    public static function createInstance()
    {
        return new ChangePasswordForm();
    }
}
?>